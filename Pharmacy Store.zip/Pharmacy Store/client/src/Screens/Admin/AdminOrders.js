import React from 'react';

const AdminOrders = () => (
	<div>
		<h1> Admin Orders</h1>
	</div>
);

export default AdminOrders;
