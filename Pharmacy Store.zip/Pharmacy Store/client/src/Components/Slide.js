import React from 'react';
import { Slide } from 'react-slideshow-image';
import './Slide.css';
import 'react-slideshow-image/dist/styles.css'
const slideImages = [
  'https://thumbor.forbes.com/thumbor/960x0/https%3A%2F%2Fspecials-images.forbesimg.com%2Fimageserve%2F5e86c57510005200067deb53%2FHealthcare-and-medical-concept--Medicine-doctor-with-stethoscope-in-hand-and-Patients%2F960x0.jpg%3Ffit%3Dscale',
  'https://image.shutterstock.com/image-vector/various-meds-pills-capsules-blisters-260nw-1409823341.jpg',
  'https://www.srisriholistichospitals.com/wp-content/uploads/2020/04/How-Online-Pharmacy-Can-Keep-You-Healthy-During-a-Lockdown-Period.jpg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSimFm0NCOX-TZ00RFRN1gXwR3TZWRkCI9N5Q&usqp=CAU',
  'https://www.nps.org.au/assets/_750x468_crop_center-center_75_none/GettyImages-862433964.jpg',
  'https://www.elsevier.com/__data/assets/image/0010/1117675/medicine-desktop.jpg',
  'https://labblog.uofmhealth.org/sites/lab/files/2021-05/Blue-Pill-Medicine-Globes-World-.jpg',
  'https://repository-images.githubusercontent.com/24479570/f2536d80-51ac-11ea-8953-68b610afdcf8'
];

const Slideshow = () => {
    return (
      <div>
        <Slide easing="ease">
          <div className="each-slide ">
            <div style={{'backgroundImage': `url(${slideImages[0]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[1]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[2]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[3]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[4]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[5]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[6]})`}}>
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[7]})`}}>
            </div>
          </div>
        </Slide>
      </div>
    )
};

export default Slideshow;