import React from "react";
import Header from "./Header";
import SearchBar from "./SearchBar";
import { useLocation } from "react-router-dom";
import Slide from "./Slide";

const Base = ({ title, children }) => {
  const flage = useLocation().pathname === "/";

  return (
    <div className="flex flex-col min-h-screen">
      <marquee
        direction="left"
        size="+2"
        className="bg-red-100 py-2 px-2 font-bold"
      >
        Hello User Welcome to Online Pharmacy Store💊🏥 Order all
        types of medicines and devices from your HOME🏡 For any query contact this toll free no. +3-9800-8799-5003.
      </marquee>
      <SearchBar />
      <Header />
      <marquee
        direction="right"
        size="1"
        className="bg-yellow-100 py-2 px-2 font-bold"
      >
        💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉
      </marquee>
      <Slide />
      {flage ? <></> : null}

      <div className="flex items-center justify-center m-8">
        <h1 className="text-3xl font-extrabold">{title}</h1>
      </div>
      <main className="flex-grow">{children}</main>
      <marquee
        direction="left"
        size="+2"
        className="bg-red-100 py-2 px-2 font-bold"
      >
         Hello User Welcome to Online Pharmacy Store💊🏥 Order all
        types of medicines and devices from your HOME🏡 For any query contact this toll free no. +3-9800-8799-5003.
      </marquee>
      <footer className="flex items-center justify-center bg-pink-800 p-6">
        <span className="text-sm text-white font-bold ">
          © {new Date().getFullYear()}, Developed by
          <a> Shakti Rani</a>
        </span>
      </footer>
      <marquee direction="right" size="+2" className=" py-2 px-2">
        💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉🚑💊💊💉💉
      </marquee>
    </div>
  );
};

export default Base;
